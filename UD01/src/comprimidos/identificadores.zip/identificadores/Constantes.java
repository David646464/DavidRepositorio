package identificadores;

public class Constantes {
    public static void main(String[] args) {
        final int NUM_ALUM_MATRICULADOS = 32; 
        final int NUM_TOTAL_SESIONES = 288; 
        final int NUM_SESIONES_SEMANALES = 9; 
        final int NUM_MESES_AÑO = 12; 

        System.out.println("Número de alumnos matriculados en el módulo de Programación:" + NUM_ALUM_MATRICULADOS);
        System.out.println("Número total de sesiones del módulo de Programación en el curso lectivo:" + NUM_TOTAL_SESIONES);
        System.out.println("Número de sesiones semanales del módulo de Programación:" + NUM_SESIONES_SEMANALES);
        System.out.println("Número de meses del año:" + NUM_MESES_AÑO);
    }
    
}
