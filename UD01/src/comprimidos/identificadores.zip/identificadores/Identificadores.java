package identificadores;
import java.time.LocalDateTime;



public class Identificadores {
    //Creador:david sánchez peso
    public static void main(String[] args) {
        
    //numeroDeTelefono;
    long numeroDeTelefono = 321673134;
    //$totalVentas 
    int totalVentas = 34;
    //mi_nombre 
     String miNombre = "david";
    //4everYoung 
    Boolean young4ever = true;
    //_variable
    Boolean _variable = false;
    //#precioProducto
    double preciProducto = 14.15;
    //usuario-email
    String usuarioEmail = "david@gmail.com";
    //$saldoCuenta
    double saldoCuenta = 45.55;
    //primeraClase
    String primeraClase = "mates";
    //mi_123_variable
    Boolean mi_123_variable = true;
    //_nombreUsuario
    String _nombreUsuario = "dsancpeso";
    //12345_valor
    byte valor12345 = 4;
    //&variable
    boolean variable = true;
    //$precioUnitario
    double precioUnitario = 0.5;
    //#contador_de_inventario
    int contador_de_inventario = 77;
    //miVariable%descuento
    double miVariableDescuento = 50.00;
    //producto1
    String producto1 = "mayonesa";
    //3añosDeExperiencia
    LocalDateTime tresAñosDeEsperiencia = LocalDateTime.now();
    //_mi_numero_de_cuenta
    long _mi_numero_de_cuenta = 1236789012;
    //mi_salario$$
    double miSalario = 1400.35;
    //$nombreCliente
    String nombreCliente = "Alfredo";
    //variable#temporal
    LocalDateTime variableTemporal = LocalDateTime.now();
    //_variable99
    Boolean _variable99 = false;
    //mi_@direccion
    String miDireccion = "Marin";
    //precio-total
    double precioTotal = 34.00;
    //5HorasTrabajo
    int cincoHorastrabajo = 5;
    //!descuento
    double descuento = 50;
    //codigoDeProducto
    long codigoDeProducto = 342135237;
    //_MiIdentificador
    int _MiIdentificador = 5523467;
    //valor#unitario
    Boolean valorUnitario = true;

    }
    
}
