package PracticasGrupos;

import java.util.Scanner;

/*Autores: 
 * David Sánchez -> Driver
 * Noa Rosas -> Navigator
 * Victoria Rúa -> Navigator
 */
public class HorasClaseAsistencia {
    public static void main(String[] args) {
        final String NOMMODULO = "Programación";
        final int HORAS = 240;

        final double AVISO = 240 / 100 * 6;
        final double PERDIDA = 240 / 100 * 10;

        System.out.println("Modulo de " + NOMMODULO);
        System.out.println("Nº de horas " + HORAS);
        System.out.println("Aviso de la perdida " + AVISO);
        System.out.println("perdida de la evaulacion continua " + PERDIDA);
        System.out.println("==================================================");
        Scanner sc = new Scanner(System.in);
        System.out.print("Dime tu numero de faltas de " + NOMMODULO + " ");
        int faltas = sc.nextInt();
        sc.close();
        String salida = (faltas < AVISO) 
        ? "No llega al 6%. No hay perdida de la evaulacion continua" 
        : (faltas < PERDIDA) 
        ? "Pasas del 6 % andate con ojo" 
        : "Pasas del 10% has perdido la evaulacion continua" ;
        System.out.println(salida);


    }
    
}
