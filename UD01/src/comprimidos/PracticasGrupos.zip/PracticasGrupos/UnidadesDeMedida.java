package unidadesDeMedida;
/*Autores: 
 * David Sánchez -> Navigator
 * Noa Rosas -> Navigator
 * Victoria Rúa -> Driver
 */
import java.util.Scanner;

public class UnidadesDeMedida {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        final double CAMPOFUTBOL = 7350; 
        final  double CANCHABALONCESTO = 420;
        final double PISTATENIS = 260.7569;
        final double PARQUEDERETIRO = 1250000;
        System.out.print("Introduce el número de hectáreas: ");
        double hectareas = sc.nextDouble();
        double metrosCuadrados = hectareas * 10000;
        System.out.println("============================================");
        System.out.println("Las hectáreas introducidas equivalen a: ");
        System.out.println(Math.round(metrosCuadrados / CAMPOFUTBOL) + " campos de fútbol");
        System.out.println(Math.round(metrosCuadrados / CANCHABALONCESTO) + " canchas de baloncesto");
        System.out.println((Math.round(metrosCuadrados / PISTATENIS)) + " pistas de tenis");
        System.out.println(Math.round(metrosCuadrados / PARQUEDERETIRO) + " parques del retiro");
        System.out.println("============================================");

        sc.close();
    }
    
}
