/*Autores: 
 * David Sánchez -> Driver
 * Noa Rosas -> Navigator
 * Victoria Rúa -> Navigator
 */
package PracticasGrupos;

import java.util.Scanner;

public class Evaulacion{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("===========================");
        System.out.println("Para introducir cada tipo de nota escribe:");
        System.out.println("1 para nota total");
        System.out.println("2 para nota media");
        System.out.println("3 para no puntua");
        System.out.println("===========================");

        System.out.println("El programa funciona?");
        int pre1 = sc.nextInt();

        System.out.println("El programa funciona y es eficiente");
        int pre2 = sc.nextInt();

        System.out.println("Usa estructuras y tipos de datos adecuados al problema");
        int pre3 = sc.nextInt();

        System.out.println("Usa identificadores adecuados");
        int pre4 = sc.nextInt();

        System.out.println("El programa es legible");
        int pre5 = sc.nextInt();

        System.out.println("Presenta la información completa al usuario");
        int pre6 = sc.nextInt();

        System.out.println("===========================");
        System.out.println("Entrega:");
        System.out.println("Entregado pon 1");
        System.out.println("Error de formato 2");
        System.out.println("No entregado pon un 3");
        int pre7 = sc.nextInt();
        sc.close();
        System.out.println("===========================");
        
        double not1 = (pre1 == 1) ? 4 : (pre1 == 2) ? 2 : 0;
        double not2 = (pre2 == 1) ? 1 : (pre2 == 2) ? 0.5 : 0;
        double not3 = (pre3 == 1) ? 1 : (pre3 == 2) ? 0.5 : 0;
        double not4 = (pre4 == 1) ? 1.5 : (pre4 == 2) ? 0.75 : 0;
        double not5 = (pre5 == 1) ? 1.5 : (pre5 == 2) ? 0.75 : 0;
        double not6 = (pre6 == 1) ? 1 : (pre6 == 2) ? 0.5 : 0;
        double notafinal = (pre7 == 1) ? not1 + not2 + not3 + not4 + not5 + not6 : (pre7 == 2) ? (not1 + not2 + not3 + not4 + not5 + not6) -1 : 0;

        System.out.println("Tu nota es: " + notafinal);
        


    }
}
