package PracticasGrupos;
/*Autores: 
 * David Sánchez -> Navigator
 * Noa Rosas -> Driver
 * Victoria Rúa -> Navigator
 */

import java.util.Scanner;

public class RecetasIngredientes {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
       
        System.out.println("============================================");
        System.out.println("COMPOTA DE MANZANA");
        System.out.println("https://www.recetasderechupete.com/compota-de-manzana-casera/12509/");
        System.out.println("============================================");
        System.out.println("Con estas cantidades será para 6 personas");
        System.out.println("INGREDIENTES:");
        System.out.println("1 kg y medio de manzanas");
        System.out.println("330 ml de agua");
        System.out.println("120 gramos de azúcar (blanca o morena)");
        System.out.println("1 cucharadita de zumo de limón");
        System.out.println("============================================");
        System.out.println("OTROS INGREDIENTES");
        System.out.println("Piel de naranja (sin el blanco)");
        System.out.println("1 ramita de canela (o una cucharadita de canela molida)");
        System.out.println("============================================");
        System.out.println("Dime el número de personas para adaptar la receta: ");
        int personas = sc.nextInt();
        sc.close();
        System.out.println("Las manzanas necesarias para " + personas + " personas,son: " + (1500 / 6) * personas + " gramos");
        System.out.println("El agua necesaria para " + personas + " personas,son: " + (330 / 6) * personas + " mililitros") ;
        System.out.println("La cantidad necesaria para " + personas + " personas, son: " + (120 / 6) * personas + " gramos");
        System.out.println("La cantidad de necesaria para " + personas + " personas,son: " + personas + " / 6   cucharaditas" );
        System.out.println("El precio de la compota sera: " + String.format("%.2f",(((personas * (1.500 / 6))  * 1.65) + ((personas * (0.120 / 6))  * 1.49) )) + " euros");
    
    }   
}
