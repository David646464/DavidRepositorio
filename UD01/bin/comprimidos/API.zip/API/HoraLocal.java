package API;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class HoraLocal {
    public static void main(String[] args) {
         //LocalDate LocalTime LocalDateTime
        System.out.println(LocalTime.now());
        System.out.println(LocalDate.now());
        System.out.println(LocalDateTime.now());
    }
}
