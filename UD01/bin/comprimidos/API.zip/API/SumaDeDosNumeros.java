package API;

import java.util.Scanner;

public class SumaDeDosNumeros {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
    
        System.out.println("Dime el primer número");
        int numero1 = sc.nextInt();
        
        System.out.println("Dime el segundo número");
        int numero2 = sc.nextInt();Object n;

        System.out.println("La suma de los dos números es: " + (numero1 + numero2));

        }
    
}
