package EstructurasDeControlFunciones;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

public class E0407Test {
    @Test
    void testDivisoresPrimos() {
        assertEquals("-1-3-", E0407.divisoresPrimos(9));
    }
}
