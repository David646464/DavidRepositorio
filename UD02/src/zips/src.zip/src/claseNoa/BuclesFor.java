package claseNoa;

public class BuclesFor {
    public static void main(String[] args) {
        String textoEjemplo = "casa de david";
        // Bucle for normal con aumento del contador
        for (int i = 0; i <= 10; i += 2) {
            System.out.println(i);
        }


        // Bucle for normal con descenso del contador
        for (int i = 10; i >= 0; i--) {
            System.out.println(i);
        }
        
    }

}
