package EstructurasDeControlFunciones;

public class a {
    static final int MAXNUM = 200;
        static final int MINNUM = -200;
    public static void main(String[] args) {
        
        for (int i = 0; i < 100; i++) {
            int solucinAnterior = (-1) + (int) (Math.random()*((2-(-1)) + 1));
            
            System.out.println(solucinAnterior);
        }
    }

    private static void calculo(String d, int a, String r) {
    }

    private static void calculo(String d, int a) {
    }
    
}
