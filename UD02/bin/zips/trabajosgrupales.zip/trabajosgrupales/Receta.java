package trabajosgrupales;

import java.util.Scanner;

public class Receta {
    public static void main(String[] args) {


        /**
         * Piero Uceda = Navigator
         * Igor García = Navigator
         * Antón Vega = Driver
         */

        int nPersonas;
        final int MANZAÑAS = 1500;
        final int AGUA = 330;
        final int ZLIMON = 1;
        final int CANELA = 1;
        final int AZUCAR = 120;
        final Double PRECIO_AZUCAR_PERSONA=0.02;
        final Double PRECIO_MAZANA_PERSONA=0.41;
        System.out.println("compota de manzana casera");
        System.out.println("https://www.recetasderechupete.com/compota-de-manzana-casera/12509/");
        System.out.println("para seis personas necesitas:");
        System.out.println("manzanas:" + MANZAÑAS + "g");
        System.out.println("agua:" + AGUA + "ml" );
        System.out.println("una cucharada de zumo de limon");
        System.out.println("azucar:" + AZUCAR + "g (blaco/moreno)");
        System.out.println("una rama de canela");
        System.out.println("para cuantas personas serian ?");
        Scanner SC = new Scanner(System.in);
        nPersonas = SC.nextInt();
        System.out.println("hacen falta " + MANZAÑAS * nPersonas/6 + "g de manzana");
        System.out.println("hacen falta " + AGUA * nPersonas/6 + "ml de agua");
        System.out.println("hacen falta " + ZLIMON * nPersonas + " " + "cucharadas de zumo de limon");
        System.out.println("hacen falta " + CANELA * nPersonas + " " + "ramas de canela");
        System.out.println("hacen falta " + AZUCAR * nPersonas/6 + "g de azucar");
        System.out.println("la manzana cuesta " + Math.round(PRECIO_MAZANA_PERSONA * nPersonas*100)/100.00 + " por " + nPersonas + " personas");
        System.out.println("el azucar cuesta " + Math.round(PRECIO_AZUCAR_PERSONA * nPersonas*100)/100.00 + " pon " + nPersonas + " personas");
        System.out.print("el precio total son: " + Math.round((PRECIO_AZUCAR_PERSONA + PRECIO_MAZANA_PERSONA) * nPersonas*100)/100.00 );

    }
}
