package trabajosgrupales;


import java.util.Scanner;

public class Evaluación {

    /**
         * Piero Uceda = Driver
         * Igor García = Navigator
         * Antón Vega = Navigator
         */

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("¿El programa funciona?: ");

        String respuesta = sc.nextLine();
        double nota1 = 0;
        nota1 = (respuesta. equals("bien")) ? nota1 + 4 : nota1;
        nota1 = (respuesta. equals("regular")) ? nota1 + 2 : nota1;
        nota1 = (respuesta. equals("mal")) ? nota1 : nota1;

        System.out.println("¿El programa funciona y es eficiente?");

        String respuesta1 = sc.nextLine();

        nota1 = (respuesta. equals("bien")) ? nota1 + 1 : nota1;
        nota1 = (respuesta. equals("regular")) ? nota1 + 0.5 : nota1;
        nota1 = (respuesta. equals("mal")) ? nota1 : nota1;

        System.out.println("¿Usa estructuras y tipos de datos adecuados al problema ?");

        respuesta1 = sc.nextLine();

        nota1 = (respuesta. equals("bien")) ? nota1 + 1 : nota1;
        nota1 = (respuesta. equals("regular")) ? nota1 + 0.5 : nota1;
        nota1 = (respuesta. equals("mal")) ? nota1 : nota1;

        System.out.println("¿Usa identificadores adecuados?");

        respuesta1 = sc.nextLine();

        nota1 = (respuesta. equals("bien")) ? nota1 + 1.5 : nota1;
        nota1 = (respuesta. equals("regular"))? nota1 + 0.75 : nota1;
        nota1 = (respuesta. equals("mal")) ? nota1: nota1;

        System.out.println("¿El programa es legible?");

        respuesta1 = sc.nextLine();

        nota1 = (respuesta. equals("bien")) ? nota1 + 1.5 : nota1;
        nota1 = (respuesta. equals("regular")) ? nota1 + 0.75 : nota1;
        nota1 = (respuesta. equals("mal")) ? nota1 : nota1;

        System.out.println("¿Presenta la información completa al usuario?");

        respuesta1 = sc.nextLine();

        nota1 = (respuesta. equals("bien")) ? nota1 + 1 : nota1;
        nota1 = (respuesta. equals("regular")) ? nota1 + 0.5 : nota1;
        nota1 = (respuesta. equals("mal")) ? nota1 : nota1;


        System.out.println("La nota total es: " + nota1);


        sc.close();
    }

}
