package trabajosgrupales;

import java.util.Scanner;

public class UnidadesdeMedida {

    public static void main(String[] args) {

        /**
         * Piero Uceda = Driver
         * Igor García = Navigator
         * Antón Vega = Navigator
         */

        Scanner sc = new Scanner(System.in);

            double hectareas;
            final double C_futbol = 0.735;
            final double C_BALON = 0.042;
            final double P_TENIS = 0.026;
            final int PRETIRO = 125;

        System.out.print("Introduzca el número de hectareas: ");
                hectareas = sc.nextDouble();

        System.out.println("Numero de campos de futbol: " + Math.round(hectareas / C_futbol));
        System.out.println("Número de campos de baloncesto:  " + Math.round(hectareas / C_BALON));
        System.out.println("Número de Pista de tenis:  " + Math.round(hectareas / P_TENIS));
        System.out.println("Número de Parques del Retiro:  " + Math.round((hectareas / PRETIRO) *100.00 )/100.00);

        sc.close();

    }

}
