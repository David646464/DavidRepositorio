package trabajosgrupales;

import java.util.Scanner;

public class E3 {
    
    public static void main(String args[]){



        /**
         * Piero Uceda = Navigator
         * Igor García = Driver
         * Antón Vega = Navigator
         */

        Scanner sc = new Scanner(System.in);

        String programación;
        final double HPRO = 240;
        final double APERC = Math.round(HPRO*6)/100 ;
        
        final double PEV = Math.round(HPRO*10)/100 ;
        double nFalt;
        boolean falt;
    

        System.out.println("Este es el numero de  sesiones de 50 minutos: " + " " +  (240*60/50) );
        System.out.println(" Este es el numero de faltas que implica apercebimiento: " + APERC);
        System.out.println(" Este es el numero de faltas que implica perdida: " + PEV);
        
        System.out.println("Introduce el numero de horas");
        nFalt = sc.nextInt();


        falt = (nFalt>=APERC) && (nFalt<24);
        System.out.println("tengo apercebimiento?" + " " + falt);
        
        falt = nFalt>=PEV ;
        System.out.println("Entonces tengo perdida?" + " " + falt);

        
    }
}
